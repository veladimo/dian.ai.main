from .tensor import Tensor
from .modules import Module
import numpy as np

class Optim(object):

    def __init__(self, module, lr):
        self.module = module
        self.lr = lr

    def step(self):
        self._step_module(self.module)

    def _step_module(self, module):

        # TODO Traverse the attributes of `self.module`,
        # if is `Tensor`, call `self._update_weight()`,
        # else if is `Module` or `List` of `Module`,
        # call `self._step_module()` recursively.

        for attr in vars(module).values():
            if isinstance(attr, Module):
                self._step_module(attr) #递归调用
            if isinstance(attr, Tensor): 
                if hasattr(attr, 'grad'): 
                    self._update_weight(attr) #更新weight
            if isinstance(attr, list):
                for elem in attr:
                    self._step_module(elem)

        # End of todo

    def _update_weight(self, tensor):
        tensor -= self.lr * tensor.grad


class SGD(Optim):

    def __init__(self, module, lr, momentum: float=0):
        super(SGD, self).__init__(module, lr)
        self.momentum = momentum

    def _update_weight(self, tensor):

        # TODO Update the weight of tensor
        # in SGD manner.
        if 'v' in vars(tensor):
            tensor.v = self.momentum * tensor.v + self.lr * tensor.grad 
        else:
            tensor.v = self.lr * tensor.grad
        tensor -= tensor.v

        # End of todo


class Adam(Optim):

    def __init__(self, module, lr=0.01, betas=(0.9, 0.999), eps=1e-08):
        super(Adam, self).__init__(module, lr)

        # TODO Initialize the attributes
        # of Adam optimizer.

        self.lr = lr
        self.beta1 = betas[0]
        self.beta2 = betas[1]
        self.eps = eps
        self.m = None
        self.v = None
        self.n = 0

        # End of todo

    def _update_weight(self, tensor):

        # TODO Update the weight of
        # tensor in Adam manner.

        ...

        # End of todo